const aboutpets = document.getElementsByClassName("about-pets");
const  logolinks = document.getElementsByClassName("logo-links");

const Navbar = document.getElementById("Navbar");
require('dotenv').config();
const uri = process.env.MONGODB_URI;
